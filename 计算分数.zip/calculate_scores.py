#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
积分计算和排名脚本
根据生产数据计算积分并生成排名
"""

import pandas as pd
import numpy as np
from datetime import datetime
import os

def calculate_scores(data):
    """
    计算积分
    积分规则：
    A1-A5：早班不低于156.84箱、中班不低于143.16箱，完成以上产量要求，即可累计积分1分。两班当日总产量不低于300箱各积4分。
    A9:早班不低于41箱、中班不低于39箱，完成以上产量要求，即可累计积分1分。两班当日总产量不低于80箱各积4分。
    
    如果报工数据为空，则表示当天台时不足，不计入竞赛天数，得分用/表示
    """
    scores = []
    
    for _, row in data.iterrows():
        machine = row['机号']
        
        # 获取甲班（中班）和乙班（早班）的计划和报工数据
        # 根据实际Excel结构：甲班对应中班，乙班对应早班
        jia_plan = row['计划'] if '计划' in row else 0
        jia_actual = row['报工'] if '报工' in row else None
        yi_plan = row['计划.1'] if '计划.1' in row else 0
        yi_actual = row['报工.1'] if '报工.1' in row else None
        
        # 检查是否有报工数据为空（台时不足）
        jia_insufficient = pd.isna(jia_actual) or jia_actual == 0
        yi_insufficient = pd.isna(yi_actual) or yi_actual == 0
        
        # 如果甲班或乙班报工数据为空，则当天台时不足
        if jia_insufficient and yi_insufficient:
            # 两个班都台时不足，不计入竞赛
            scores.append({
                '机号': machine,
                '甲班(中班)产量': '/',
                '甲班(中班)积分': '/',
                '乙班(早班)产量': '/',
                '乙班(早班)积分': '/',
                '总产量': '/',
                '台时不足': True
            })
            continue
        elif jia_insufficient:
            # 只有甲班台时不足
            scores.append({
                '机号': machine,
                '甲班(中班)产量': '/',
                '甲班(中班)积分': '/',
                '乙班(早班)产量': yi_actual,
                '乙班(早班)积分': '/',
                '总产量': '/',
                '台时不足': True
            })
            continue
        elif yi_insufficient:
            # 只有乙班台时不足
            scores.append({
                '机号': machine,
                '甲班(中班)产量': jia_actual,
                '甲班(中班)积分': '/',
                '乙班(早班)产量': '/',
                '乙班(早班)积分': '/',
                '总产量': '/',
                '台时不足': True
            })
            continue
        
        # 计算总产量
        total_production = jia_actual + yi_actual
        
        # 根据机号确定积分规则
        if machine in ['A01', 'A02', 'A03', 'A04', 'A05']:
            # A1-A5规则
            jia_threshold = 143.16  # 中班阈值
            yi_threshold = 156.84   # 早班阈值
            total_threshold = 300   # 总产量阈值
            total_bonus = 4         # 总产量达标奖励
        elif machine == 'A09':
            # A9规则
            jia_threshold = 39      # 中班阈值
            yi_threshold = 41       # 早班阈值
            total_threshold = 80    # 总产量阈值
            total_bonus = 4         # 总产量达标奖励
        else:
            # 其他机号，使用A1-A5规则
            jia_threshold = 143.16
            yi_threshold = 156.84
            total_threshold = 300
            total_bonus = 4
        
        # 计算甲班（中班）积分
        jia_score = 0
        if jia_actual >= jia_threshold:
            jia_score += 1
        if total_production >= total_threshold:
            jia_score += total_bonus
        
        # 计算乙班（早班）积分
        yi_score = 0
        if yi_actual >= yi_threshold:
            yi_score += 1
        if total_production >= total_threshold:
            yi_score += total_bonus
        
        # 记录结果
        scores.append({
            '机号': machine,
            '甲班(中班)产量': jia_actual,
            '甲班(中班)积分': jia_score,
            '乙班(早班)产量': yi_actual,
            '乙班(早班)积分': yi_score,
            '总产量': total_production,
            '台时不足': False
        })
    
    return pd.DataFrame(scores)

def calculate_total_scores(all_daily_scores):
    """
    计算每个机台的总分
    """
    total_scores = {}
    
    for date, scores_df in all_daily_scores.items():
        for _, row in scores_df.iterrows():
            machine = row['机号']
            
            # 只计算有效记录（非台时不足）
            if not row['台时不足']:
                if machine not in total_scores:
                    total_scores[machine] = {
                        '甲班总分': 0,
                        '乙班总分': 0,
                        '总积分': 0,
                        '有效天数': 0
                    }
                
                total_scores[machine]['甲班总分'] += row['甲班(中班)积分']
                total_scores[machine]['乙班总分'] += row['乙班(早班)积分']
                total_scores[machine]['总积分'] += row['甲班(中班)积分'] + row['乙班(早班)积分']
                total_scores[machine]['有效天数'] += 1
    
    return total_scores

def calculate_rankings(scores_df, total_scores=None):
    """
    计算排名，区分甲乙班
    包含所有记录，但台时不足的记录积分为'/'，排名为'-'
    """
    rankings = []
    
    # 分离有效记录和台时不足记录
    valid_scores = scores_df[scores_df['台时不足'] == False].copy()
    insufficient_scores = scores_df[scores_df['台时不足'] == True].copy()
    
    # 甲班排名
    jia_rankings = []
    
    # 有效记录的甲班排名
    if len(valid_scores) > 0:
        valid_jia = valid_scores[['机号', '甲班(中班)产量', '甲班(中班)积分']].copy()
        valid_jia['班次'] = '甲班'
        valid_jia['排名'] = valid_jia['甲班(中班)积分'].rank(method='dense', ascending=False).astype(int)
        valid_jia = valid_jia.rename(columns={
            '甲班(中班)产量': '产量',
            '甲班(中班)积分': '积分'
        })
        jia_rankings.append(valid_jia)
    
    # 台时不足记录的甲班排名
    if len(insufficient_scores) > 0:
        insufficient_jia = insufficient_scores[['机号', '甲班(中班)产量', '甲班(中班)积分']].copy()
        insufficient_jia['班次'] = '甲班'
        insufficient_jia['排名'] = '-'  # 台时不足排名为'-'
        insufficient_jia = insufficient_jia.rename(columns={
            '甲班(中班)产量': '产量',
            '甲班(中班)积分': '积分'
        })
        jia_rankings.append(insufficient_jia)
    
    # 乙班排名
    yi_rankings = []
    
    # 有效记录的乙班排名
    if len(valid_scores) > 0:
        valid_yi = valid_scores[['机号', '乙班(早班)产量', '乙班(早班)积分']].copy()
        valid_yi['班次'] = '乙班'
        valid_yi['排名'] = valid_yi['乙班(早班)积分'].rank(method='dense', ascending=False).astype(int)
        valid_yi = valid_yi.rename(columns={
            '乙班(早班)产量': '产量',
            '乙班(早班)积分': '积分'
        })
        yi_rankings.append(valid_yi)
    
    # 台时不足记录的乙班排名
    if len(insufficient_scores) > 0:
        insufficient_yi = insufficient_scores[['机号', '乙班(早班)产量', '乙班(早班)积分']].copy()
        insufficient_yi['班次'] = '乙班'
        insufficient_yi['排名'] = '-'  # 台时不足排名为'-'
        insufficient_yi = insufficient_yi.rename(columns={
            '乙班(早班)产量': '产量',
            '乙班(早班)积分': '积分'
        })
        yi_rankings.append(insufficient_yi)
    
    # 合并所有排名
    all_rankings = []
    for ranking_list in [jia_rankings, yi_rankings]:
        if ranking_list:
            all_rankings.extend(ranking_list)
    
    if all_rankings:
        all_rankings_df = pd.concat(all_rankings, ignore_index=True)
        # 排序：先按排名（数字在前，'-'在后），再按积分，最后按产量
        all_rankings_df = all_rankings_df.sort_values(['排名', '积分', '产量'], 
                                                     ascending=[True, False, False], 
                                                     na_position='last')
        return all_rankings_df
    else:
        return pd.DataFrame(columns=['机号', '产量', '积分', '班次', '排名', '日期'])

def process_excel_file(file_path):
    """
    处理Excel文件，计算所有sheet的积分和排名
    """
    # 读取Excel文件的所有sheet
    excel_file = pd.ExcelFile(file_path)
    
    results = {}
    all_daily_rankings = []
    all_daily_scores = {}
    
    for sheet_name in excel_file.sheet_names:
        print(f"处理日期: {sheet_name}")
        
        # 读取数据
        df = pd.read_excel(file_path, sheet_name=sheet_name)
        
        # 清理列名，去除空格
        df.columns = df.columns.str.strip()
        
        # 计算积分
        scores = calculate_scores(df)
        results[f"{sheet_name}_积分"] = scores
        all_daily_scores[sheet_name] = scores
        
        # 计算排名
        rankings = calculate_rankings(scores)
        rankings['日期'] = sheet_name
        all_daily_rankings.append(rankings)
        
        # 统计有效记录
        valid_scores = scores[scores['台时不足'] == False]
        insufficient_count = len(scores[scores['台时不足'] == True])
        
        if len(valid_scores) > 0:
            print(f"  - 甲班最高积分: {valid_scores['甲班(中班)积分'].max()}")
            print(f"  - 乙班最高积分: {valid_scores['乙班(早班)积分'].max()}")
            print(f"  - 台时不足机台数: {insufficient_count}")
        else:
            print(f"  - 当日所有机台台时不足，不计入竞赛")
            print(f"  - 台时不足机台数: {insufficient_count}")
    
    # 计算总分
    total_scores = calculate_total_scores(all_daily_scores)
    
    # 创建总分排名表
    total_rankings = []
    for machine, scores in total_scores.items():
        # 甲班总分排名
        total_rankings.append({
            '机号': machine,
            '班次': '甲班',
            '总积分': scores['甲班总分'],
            '有效天数': scores['有效天数'],
            '平均积分': round(scores['甲班总分'] / scores['有效天数'], 2) if scores['有效天数'] > 0 else 0
        })
        # 乙班总分排名
        total_rankings.append({
            '机号': machine,
            '班次': '乙班',
            '总积分': scores['乙班总分'],
            '有效天数': scores['有效天数'],
            '平均积分': round(scores['乙班总分'] / scores['有效天数'], 2) if scores['有效天数'] > 0 else 0
        })
    
    # 计算总分排名
    if total_rankings:
        total_rankings_df = pd.DataFrame(total_rankings)
        total_rankings_df['排名'] = total_rankings_df.groupby('班次')['总积分'].rank(method='dense', ascending=False).astype(int)
        total_rankings_df = total_rankings_df.sort_values(['班次', '排名', '总积分', '平均积分'], ascending=[True, True, False, False])
        results['总分排名'] = total_rankings_df
    
    # 合并所有日期的排名
    all_rankings_df = pd.concat(all_daily_rankings, ignore_index=True)
    results['总排名'] = all_rankings_df
    
    return results

def main():
    """
    主函数
    """
    file_path = '/Users/apple/Documents/cursor/test2/data.xlsx'
    
    if not os.path.exists(file_path):
        print(f"文件不存在: {file_path}")
        return
    
    print("开始处理数据...")
    
    # 处理Excel文件
    results = process_excel_file(file_path)
    
    # 输出结果到新的Excel文件
    output_file = '/Users/apple/Documents/cursor/test2/积分排名结果.xlsx'
    
    with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
        # 写入总分排名
        if '总分排名' in results:
            results['总分排名'].to_excel(writer, sheet_name='总分排名', index=False)
        
        # 写入总排名
        results['总排名'].to_excel(writer, sheet_name='总排名', index=False)
        
        # 写入每日积分和排名
        for sheet_name, data in results.items():
            if sheet_name not in ['总排名', '总分排名']:
                data.to_excel(writer, sheet_name=sheet_name, index=False)
    
    print(f"\n结果已保存到: {output_file}")
    
    # 显示总分排名
    if '总分排名' in results:
        print("\n总分排名:")
        print(results['总分排名'].to_string(index=False))
    
    # 显示总排名前10名
    print("\n总排名前10名:")
    print(results['总排名'].head(10).to_string(index=False))
    
    # 显示每日统计
    print("\n每日统计:")
    if len(results['总排名']) > 0:
        # 只统计有效记录（排除台时不足的记录）
        valid_rankings = results['总排名'][results['总排名']['积分'] != '/'].copy()
        if len(valid_rankings) > 0:
            # 将积分列转换为数值类型
            valid_rankings['积分'] = pd.to_numeric(valid_rankings['积分'], errors='coerce')
            valid_rankings['产量'] = pd.to_numeric(valid_rankings['产量'], errors='coerce')
            
            daily_stats = valid_rankings.groupby('日期').agg({
                '积分': ['max', 'mean'],
                '产量': 'sum'
            }).round(2)
            print(daily_stats)
        else:
            print("所有日期都因台时不足不计入竞赛")
    else:
        print("所有日期都因台时不足不计入竞赛")
    
    # 显示台时不足统计
    print("\n台时不足统计:")
    for sheet_name in results.keys():
        if sheet_name.endswith('_积分'):
            date = sheet_name.replace('_积分', '')
            scores = results[sheet_name]
            insufficient_count = len(scores[scores['台时不足'] == True])
            valid_count = len(scores[scores['台时不足'] == False])
            print(f"{date}: 有效记录 {valid_count} 条, 台时不足 {insufficient_count} 条")

if __name__ == "__main__":
    main()
